chrome.extension.sendMessage(null, {log:"log"}, function (response) {
    if (response.isNetSpeed === true) {
        console.log("正在使用模拟低速功能");
    }
    if (response.isDebug === true) {
        console.log("正在使用debug 模式");
    }
});
