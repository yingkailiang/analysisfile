var storage = window.localStorage;
var slow = -1;
var isNetSpeed;
chrome.webRequest.onBeforeRequest.addListener(function (info) {
        var obj = {};
        isNetSpeed = storage.getItem('isnetspeeddelay');
        //模拟低俗网络
        if ("false"!== isNetSpeed && (slow = storage.getItem('netspeeddelay')) && slow > 0) {
            UIIL.pause(slow);
        }

        //debug模式
        if (storage.getItem('debug')!== "false") {
            if (info.type === "script" || info.type === "stylesheet") {
                obj.redirectUrl = info.url.replace(/-min.|.min./g, '.');
            }
        }

        return obj;

    }, // filters
    {
        urls:[
            "http://*/*"
        ]
    }, // extraInfoSpec
    ["blocking"]);


chrome.extension.onMessage.addListener(
    function (request, sender, sendResponse) {
        if(request.log == "log"){
            sendResponse({
                isNetSpeed: storage.getItem('isnetspeeddelay') !== "false",
                isDebug : storage.getItem('debug') !== "false"
            })
        }
    });